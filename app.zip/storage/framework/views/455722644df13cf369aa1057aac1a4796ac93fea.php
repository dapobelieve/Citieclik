<?php $__currentLoopData = $sdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="card mb-4">
      	<div class="card-header">Category: <span class="badge badge-pill badge-primary"><?php echo e($data->catty->category); ?></span></div>
      	<div class="card-block">
        	<div class="d-flex">
                <a class="pr-4 hidden-xs-down" href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>" style="max-width: 225px;">
                    <?php echo $data->getImages(); ?> 
                </a>
          		<div>
            		<h5>
                        <a class="navi-link" href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>"><?php echo e($data->title); ?></a>
                    </h5>
            		<div class="product-buttons">
		              <a href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>" style="color: #0da9ef; text-transform: capitalize;" >Details</a>
		            </div>
          		</div>
        	</div>
      	</div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>