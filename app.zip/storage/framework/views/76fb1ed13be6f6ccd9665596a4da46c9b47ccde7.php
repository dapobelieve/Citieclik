<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- Body-->
  <body>
    <?php echo $__env->yieldContent('request-modal'); ?>
    
        <div class="show-navy" id="mySidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <?php if(Auth::check()): ?>
              <a class="side-link" href="<?php echo e(route('profile.index', ['slug' =>Auth::User()->slug ])); ?>">
                <span class="side-link" >Hello</span>, <?php echo e(Auth::User()->first_name); ?> 
              </a>
              <?php endif; ?>
            <a class="side-link" href="/"><span>Home</span></a>
            <hr>
            <small style=" margin-left: 33%">Categories</small>
            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-btn" href=""><span><?php echo e($data->name); ?></span>
                </a>
                <div class="dropdown-cont">
                    <?php $__currentLoopData = $data->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="sub-nav-2" href="<?php echo e(route('category.index2', [$data->slug, $layer->slug])); ?>">
                            <?php echo e($layer->category); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a class="sub-nav-2" href="<?php echo e(route('category.index', [$data->slug])); ?>">View all</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(Auth::check()): ?>
                <a class="side-link" href="<?php echo e(route('profile.index', ['slug' =>Auth::User()->slug ])); ?>">Dashboard</a>
                <a class="side-link" href="<?php echo e(route('auth.signout')); ?>"><span>Logout</span></a>
            <?php endif; ?>
            <?php if(Auth::check() && Auth::User()->isAdmin()): ?>
                 <a class="side-link" href="<?php echo e(route('admin.home')); ?>">Admin</a>
              <?php endif; ?>
            <a href="<?php echo e(route('addproduct')); ?>" class="postBtn">Post Ad</a>
        </div>
    <header class="navbar fix-header">

      <!-- Search-->
      
      <div class="site-branding">
        <div class="inner">
            <a class="offcanvas-toggle menu-toggle" onclick="showNav()"></a>
        </div>
      </div>
            <div class="top-nav">
                <!-- Site Logo-->
                <div class="top-item item-a">
                    <a class="site-logo" href="/"><img src="/assets/img/logo/citilogo.png" alt="Citieclik"></a>
                </div>
                <div class="top-item item-b">
                    <a href="<?php echo e(route('addproduct')); ?>" class="postBtn top-item-link">
                        Post Ad
                    </a>
                </div>
                <?php if(!Auth::check()): ?>
                    <div class="top-item item-c">
                        <a href="<?php echo e(route('signup')); ?>" class="top-item-link">Login</a>
                    </div>
                <?php endif; ?> 
                <?php if(Auth::check()): ?>
                <div class="top-item">
                    <div class="toolbar">
                        
                        <div class="account"><a href="#"></a><i class="icon-head"></i>
                            <ul class="toolbar-dropdown pull-left">
                                  <li class="sub-menu-title" style="font-size: 12px;"><span>Dear,</span><?php echo e(Auth::User()->first_name); ?></li>
                                    <li><a href="<?php echo e(route('profile.index', ['slug' =>Auth::User()->slug ])); ?>">Dashboard</a></li>
                                    <li><a href="<?php echo e(route('profile.service', ['slug' =>Auth::User()->slug ])); ?>">My Services</a></li>
                                    <li><a href="<?php echo e(route('profile.products', ['slug' =>Auth::User()->slug ])); ?>">My Products</a></li>
                                    <li><a href="<?php echo e(route('profile.request', ['slug' =>Auth::User()->slug ])); ?>">My Requests</a></li>
                                    <?php if(Auth::User()->isAdmin()): ?>
                                        <li><a href="<?php echo e(route('admin.home')); ?>">Admin</a></li>
                                    <?php endif; ?>
                                  <li class="sub-menu-separator"></li>
                                  
                                  <li><a href="<?php echo e(route('auth.signout')); ?>"> <i class="icon-unlock"></i>Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                    
                <?php endif; ?>    
            </div>     
    </header>
    <?php echo $__env->yieldContent('topcat'); ?>
    <!-- Off-Canvas Wrapper-->
    <div id="app" class="offcanvas-wrapper">
      <!-- Page Content-->
      <?php echo $__env->yieldContent('content'); ?>
      <!-- Site Footer-->
      <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <script>
        function showNav() {
            document.getElementById("mySidenav").style.display = "block";
        }
        function closeNav() {
            document.getElementById("mySidenav").style.display = "none";
        }

        var dropdown = document.getElementsByClassName('dropdown-btn');
        var i;

        for (i = 0; i < dropdown.length; i++) {
            dropdown[i].addEventListener('click', function (event) {
                event.preventDefault();
                this.classList.toggle('activedrop')
                var dropcontent = this.nextElementSibling;

                if ( dropcontent.style.display === 'block') {
                    dropcontent.style.display = 'none'
                }else {
                    dropcontent.style.display = 'block'
                }
            })
        }
    </script>
    <a class="scroll-to-top-btn" href="#"><i class="icon-arrow-up"></i></a>
    <!-- Backdrop-->
    
    <!-- JavaScript (jQuery) libraries, plugins and custom scripts-->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="/assets/js/vendor.min.js"></script>
    <script src="/assets/js/scripts.min.js"></script>
    <script src="/assets/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="/js/jquery.min.js"></script>
    <!-- Customizer scripts-->
    <script src="/assets/customizer/customizer.min.js"></script>  
    <?php echo $__env->yieldContent('script'); ?>    
  </body>

</html>