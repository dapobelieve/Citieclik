<?php $__env->startSection('title'); ?>
<?php echo e($cat->name); ?> | Citieclik
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Title-->
            <div class="page-title">
                <div class="container">
                    <div class="column">
                        <h1><?php echo e($cat->name); ?></h1>
                    </div>
                    <div class="column">
                        <ul class="breadcrumbs">
                            <li><a href="#">Home</a>
                            </li>
                            <li class="separator">&nbsp;</li>
                            <li><?php echo e($cat->name); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Page Content-->
            <div class="container padding-bottom-3x mb-1">
                <div class="row hereIt">
                    <!-- Products-->
                    <div class="col-xl-9 col-lg-8">
                        <!-- Shop Toolbar-->
                        <div class="shop-toolbar padding-bottom-1x mb-2">
                            <div class="column">
                               <?php echo $__env->make('service.layout.state-filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                            <div class="column">
                            </div>
                        </div>
                        <!-- Product-->
                       <?php echo $__env->make('category.layout.feed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <div class="pt-2">
                            <!-- Pagination-->
                        </div>
                    </div>
                    <!-- Sidebar          -->
                    <div class="col-xl-3 col-lg-4">
                        <?php echo $__env->make('service.layout.cat-filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>

            
            <!-- Page Content Ends -->
            
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/assets/js/isotope.js"></script>
<script>
    var url1 = "service/state/location/";
</script>
<script src="/assets/js/service.js"></script>
<script type="text/javascript">

function isotopeIts(theValue)
{
    $grid.isotope({ filter: theValue });
}


    var checkboxes = $('.subCatWid');
    checkboxes.on("change",".dcheck", function(event) {
    // map input values to an array
    var inclusives = [];
    // inclusive filters from checkboxes
    checkboxes.each( function( i, elem ) {
        // if checkbox, use value if checked
        if ( elem.checked ) {
            inclusives.push( elem.value );
        }
    });

        var filterValue = inclusives.length ? inclusives.join(', ') : '*';
        isotopeIts(filterValue);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>