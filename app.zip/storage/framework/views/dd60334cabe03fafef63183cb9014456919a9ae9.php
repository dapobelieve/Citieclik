<?php $__env->startSection('style'); ?>
	 
  
  <link href="/dist/ui/trumbowyg.min.css" rel="stylesheet">
  
  <script type='text/javascript'>
	
	function preview_image(event) 
	{
	 var reader = new FileReader();
	 reader.onload = function()
	 {
	  var output = document.getElementById('output_image');
	  output.src = reader.result;
	 }
	 reader.readAsDataURL(event.target.files[0]);
	}
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Edit service | Citieclik
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-title">
        <div class="container">
          <div class="column">
            <h1>Edit</h1>
          </div>
          <div class="column">
            <ul class="breadcrumbs">
              <li><a href="index-2.html">Home</a>
              </li>
              <li class="separator">&nbsp;</li>
              <li>Edit</li>
            </ul>
          </div>
        </div>
      </div>
		<!-- Page Content-->
      	<div class="container padding-bottom-3x mb-2">
	        <div class="row">
	          <!-- Checkout Adress-->
	          	<div class="col-xl-9 col-lg-8">
		          <?php if(count($errors) > 0): ?>
		            <div class="alert alert-danger alert-dismissible fade show margin-bottom-1x">
			            <span class="alert-close" data-dismiss="alert"></span><i class="icon-ban"></i>&nbsp;&nbsp;
			            <strong>Error alert:</strong>
				            <ul>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li> <?php echo e($error); ?> </li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
		            </div>
		          <?php endif; ?>
		            <h4>Edit Service</h4>
		            <hr>
		            <hr class="padding-bottom-1x">
		            <form 
		            	class="" 
		            	role="form" 
		            	method="POST" 
		            	enctype="multipart/form-data" 
		            	action="<?php echo e(route('service.edit', $sdata->id)); ?>">

		            
			            <div class="row" style="margin-top: 20px;">
			              	<div class="col-sm-12">
				                <div class="form-group <?php echo e($errors->has('serTitle') ? ' has-error' : ''); ?>">
				                  	<label for="checkout-fn">Service Title</label>
				                  	<input class="form-control" name="serTitle" type="text" placeholder="name of your service programmer, hair stylist, barber etc" value="<?php echo e(old('serTitle') ?: $sdata->title); ?>" required>
				                  	<?php if($errors->has('serTitle')): ?>
										<p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('serTitle')); ?></p>
					                	
				                	<?php endif; ?>
				                </div>
			              	</div>
			            </div>
			            <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group <?php echo e($errors->has('serCat') ? ' has-error' : ''); ?>">
                                    <label for="checkout-country">Category</label>
                                    <select class="form-control" onchange="getSubCat(this.value)" name="serCat" id="serCat" value="<?php echo e(Request::old('serCat') ?: ''); ?>">
                                        <option>Choose a Category</option>
                                        <?php if($sdata->type == 'p'): ?>
                                            <?php $__currentLoopData = $cats->where('type', 'p'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php elseif($sdata->type == 's'): ?>
                                            <?php $__currentLoopData = $cats->where('type', 's'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                    </select>
                                    <?php if($errors->has('serCat')): ?>
                                        <p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('serCat')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <span id="subcatty"></span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <span id="subcatty2"></span>
                                </div>
                            </div>

                        </div>
			            <div class="row">
			              	<div class="col-sm-6">
				                <div class="form-group <?php echo e($errors->has('serState') ? ' has-error' : ''); ?>">
				                  	<label for="checkout-country">State</label>
				                  	<select class="form-control" onchange="getLoco(this.value)" name="serState" id="serState" value="<?php echo e(old('serState') ?: ''); ?>">
				                    	<option value="<?php echo e($sdata->state->id); ?>"><?php echo e($sdata->state->state); ?></option>
					                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
					                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                  	</select>
				                  	<?php if($errors->has('serState')): ?>
										<p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('serState')); ?></p>
				                	<?php endif; ?>
				                </div>
			              	</div>
			              	<div class="col-sm-6">
                                <div class="form-group <?php echo e($errors->has('location') ? ' has-error' : ''); ?>">

                                    <span id="locations"></span>
                                    <?php if($errors->has('location')): ?>
                                        <p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('location')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
			            </div>
			            <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="col-form-label">Select Image(s) *only jpg, jpeg & png formats allowed. Max size allowed is 2mb.</label>
                                    <div class="">
                                        <div class="custom-file">
                                            <input type="file" name="image[]" multiple>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>			            
			            <div class="row padding-bottom-1x">
			            	<div class="col-sm-12">
			            		<div class="form-group <?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
				            		<label for="checkout-description">Description</label>
				            		<textarea class="my-editor" name="description" value="<?php echo e(old('description') ?: ''); ?>" placeholder="Your description goes here..."><?php echo e($sdata->description); ?></textarea>
			                  		<?php if($errors->has('description')): ?>
										<p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('description')); ?></p>
				                	<?php endif; ?>
			            		</div>
			            	</div>
			            </div>
			             <?php if($sdata->type == 'p'): ?>
			            	<input type="hidden" name="typo" value="p">
			            <?php elseif($sdata->type == 's'): ?>
			            	<input type="hidden" name="typo" value="s">
			            <?php endif; ?>
			            <div class="form-group">
			            	<button type="submit" class="btn btn-outline-primary btn-block">Submit</button>
			            </div>
			            <?php echo e(csrf_field()); ?>

			        </form>
	          	</div>
	          	<!-- Sidebar          -->
	          	<div class="col-xl-3 col-lg-4">
		            
	          	</div>
	        </div>
      	</div>
  	<!--Page Content-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script type="text/javascript" src="/js/jquery.min.js"></script>
<script src="/dist/trumbowyg.min.js"></script>

<script src="/assets/js/addservice.js"></script>
<script type="text/javascript">
	$('.my-editor').trumbowyg({
		autogrow: true,
	 	btns: [
	        // ['viewHTML'],
	        ['formatting'],
	        'btnGrp-semantic',
	        ['superscript', 'subscript'],
	        ['link'],
	        'btnGrp-justify',
	        'btnGrp-lists',
	        ['horizontalRule'],
	        ['removeformat'],
	    ]
	});   
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>