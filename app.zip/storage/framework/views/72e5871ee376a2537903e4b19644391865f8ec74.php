<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Search Results | Citieclik
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Title-->
      <div class="page-title">
        <div class="container">
          <div class="column">
            <h1>Search Result</h1>
          </div>
          <div class="column">
            <ul class="breadcrumbs">
              <li><a href="<?php echo e(route('home')); ?>">Home</a>
              </li>
              <li class="separator">&nbsp;</li>
              <li>Search Results</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Page Content-->
      <div class="container padding-bottom-3x mb-1">
        <div class="row hereIt">
          <!-- Products-->
          <div class="col-xl-9 col-lg-8">
            <?php if(!$sdata->count()): ?>
              <h4>We could not find any, please search for another</h4>
            <?php else: ?>
              <h4>We found <?php echo e($sdata->count()); ?> results</h4>
              <?php echo $__env->make('search.template.results', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
            <?php echo e($sdata->render()); ?>

          </div>
          <!-- Sidebar          -->
          <div class="col-xl-3 col-lg-4">
            
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/assets/js/isotope.js"></script>
<script>
  var url1 = "service/state/location/";
  var url2 = "service/category/getscat/";
</script>
<script src="/assets/js/service.js"></script>
<script type="text/javascript">

function isotopeIts(theValue)
{
  $grid.isotope({ filter: theValue });
}


  var checkboxes = $('.subCatWid');
  checkboxes.on("change",".dcheck", function(event) {
  // map input values to an array
  console.log(event.target.value);
  var inclusives = [];
  // inclusive filters from checkboxes
  checkboxes.each( function( i, elem ) {
    // if checkbox, use value if checked
    if ( elem.checked ) {
      inclusives.push( elem.value );
    }
  });
  // console.log(inclusives);

    // var filterValue = inclusives.length ? inclusives.join(', ') : '*';
    // console.log(filterValue); 
    // isotopeIts(filterValue);
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>