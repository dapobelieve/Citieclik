<?php $__currentLoopData = $sdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="card mb-4">
      	<div class="card-header">Category: <span class="badge badge-pill badge-primary"><?php echo e($data->catty->category); ?></span></div>
      	<div class="card-block">
        	<div class="d-flex"><a class="pr-4 hidden-xs-down" href="shop-single.html" style="max-width: 225px;"><img src=<?php echo e($data->getImages()); ?> alt="Product" height="50" style="height: 150px !important;"></a>
          		<div>
            		<h5><a class="navi-link" href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>"><?php echo e($data->title); ?></a></h5>
		            <h6>
		              
		            </h6>
            		
            		<div class="product-buttons">
		              <a href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>" class="btn btn-outline-primary btn-sm">Details</a>
		            </div>
          		</div>
        	</div>
      	</div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>