<?php $__env->startSection('title'); ?>
Services | Citieclik
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Title-->
      <div class="page-title">
        <div class="container">
          <div class="column">
            <h1>Listed Services</h1>
          </div>
          <div class="column">
            <ul class="breadcrumbs">
              <li><a href="#">Home</a>
              </li>
              <li class="separator">&nbsp;</li>
              <li>Listed Services</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Page Content-->
      <div class="container padding-bottom-3x mb-1">
        <div class="row hereIt">
          <!-- Products-->
          <div class="col-xl-9 col-lg-8 push-xl-3 push-lg-4">
            <!-- Shop Toolbar-->
            <div class="shop-toolbar padding-bottom-1x mb-2">
              <div class="column">
                <?php echo $__env->make('service.layout.state-filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </div>
              <div class="column">
                  
              </div>
            </div>
            <!-- Products Grid-->
            <?php echo $__env->make('service.layout.feeds', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
          <!-- Sidebar          -->
          <div class="col-xl-3 col-lg-4 pull-xl-9 pull-lg-8">
            <?php echo $__env->make('service.layout.cat-filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/assets/js/isotope.js"></script>
<script>
  var url1 = "service/state/location/";
  // var url2 = "service/category/getscat/";
</script>
<script src="/assets/js/service.js"></script>
<script type="text/javascript">

function isotopeIts(theValue)
{
  $grid.isotope({ filter: theValue });
}


  var checkboxes = $('.subCatWid');
  checkboxes.on("change",".dcheck", function(event) {
  // map input values to an array
  // console.log(event.target.value);
  var inclusives = [];
  // inclusive filters from checkboxes
  checkboxes.each( function( i, elem ) {
    // if checkbox, use value if checked
    if ( elem.checked ) {
      inclusives.push( elem.value );
    }
  });
    var filterValue = inclusives.length ? inclusives.join(', ') : '*';
    isotopeIts(filterValue);
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>