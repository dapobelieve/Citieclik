<nav class="pcoded-navbar">
		<div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
		<div class="pcoded-inner-navbar main-menu">
			<div class="pcoded-navigation-label">Navigation</div>
			<ul class="pcoded-item pcoded-left-item">
					<li class="<?php echo e(Request::is( 'dashboard' ) ? ' active' : ''); ?>  pcoded-trigger">
						<a href="<?php echo e(route('admin.home')); ?>">
							<span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
							<span class="pcoded-mtext">Dashboard</span>
						</a>
					</li>
					<li class="pcoded-hasmenu <?php echo e(Request::is( 'admin/users*' ) ? ' active pcoded-trigger' : ''); ?>">
						<a href="javascript:void(0)">
							<span class="pcoded-micon"><i class="ti-user"></i><b>D</b></span>
							<span class="pcoded-mtext">Users</span>
						</a>
						<ul class="pcoded-submenu">
							<li class="<?php echo e(Request::is('admin/users/all-users') ? 'active' : ''); ?>">
								<a href="<?php echo e(route('admin.users')); ?>">
								<span class="pcoded-micon"><i class="ti-angle-right"></i></span>
								<span class="pcoded-mtext">All Users</span>
								<span class="pcoded-mcaret"></span>
								</a>
							</li>
							<li class="<?php echo e(Request::is('admin/users/subscribed-users') ? 'active' : ''); ?>">
								<a href="<?php echo e(route('admin.subscribed-users')); ?>">
								<span class="pcoded-micon"><i class="ti-angle-right"></i></span>
								<span class="pcoded-mtext">Subscribed Users</span>
								<span class="pcoded-mcaret"></span>
								</a>
							</li>
							
						</ul>
					</li>
					<li class=" <?php echo e(Request::is( 'admin/category' ) ? ' active' : ''); ?> pcoded-trigger">
						<a href="<?php echo e(route('admin.category')); ?>">
							<span class="pcoded-micon"><i class="ti-layout-tab-v"></i><b>D</b></span>
							<span class="pcoded-mtext">Category</span>
						</a>
					</li>
                    <li class="pcoded-hasmenu pcoded-trigger">
                        <a href="<?php echo e(route('admin.agents')); ?>">
                            <span class="pcoded-micon"><i class="ti-user"></i><b>D</b></span>
                            <span class="pcoded-mtext">Agents</span>
                        </a>
                    </li>
					
				</ul>
					</li>
		</div>
	</nav>