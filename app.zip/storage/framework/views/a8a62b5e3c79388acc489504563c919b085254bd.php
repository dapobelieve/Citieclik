 <?php if(Auth::check()): ?>
        <div class="toolbar">
          <div class="inner">
            <div class="tools">
              <div class="search"><i class="icon-search"></i></div>
              <div class="account"><a href="#"></a><i class="icon-head"></i>
                <ul class="toolbar-dropdown pull-left">
                  <li class="sub-menu-title" style="font-size: 12px;"><span>Dear,</span><?php echo e(Auth::User()->first_name); ?></li>
                    <li><a href="<?php echo e(route('profile.index', ['slug' =>Auth::User()->slug ])); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('profile.service', ['slug' =>Auth::User()->slug ])); ?>">My Services</a></li>
                    <li><a href="<?php echo e(route('profile.products', ['slug' =>Auth::User()->slug ])); ?>">My Products</a></li>
                    <li><a href="<?php echo e(route('profile.request', ['slug' =>Auth::User()->slug ])); ?>">My Requests</a></li>
                    <?php if(Auth::User()->isAdmin()): ?>
                        <li><a href="<?php echo e(route('admin.home')); ?>">Admin</a></li>
                    <?php endif; ?>
                  <li class="sub-menu-separator"></li>
                  <li><a href="<?php echo e(route('auth.signout')); ?>"> <i class="icon-unlock"></i>Logout</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      <?php endif; ?>

      <?php if(!Auth::check()): ?>
        <div class="toolbar">
          <div class="inner">
            <div class="tools ">
              <a href="<?php echo e(route('signup')); ?>" class="sagent">Sign up / Sign in</a>
            </div>
          </div>
        </div>
      <?php endif; ?>