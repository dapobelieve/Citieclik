<nav class="offcanvas-menu">
        <ul class="menu">
              <li class="<?php echo e(Request::is( '/' ) ? ' active' : ''); ?>"><a href="/"><span>Home</span></a>
              </li>
              
              <li class=""><span><a href="<?php echo e(route('service')); ?>">Services</a><span class="sub-menu-toggle"></span></span>
              </li>
              <li class=""><span><a href="<?php echo e(route('product')); ?>">Products</a><span class="sub-menu-toggle"></span></span>
              </li>
              <li class="sub-menu-separator"></li>
              <?php if(Auth::check()): ?>
                <li><a href="<?php echo e(route('profile.index', ['slug' =>Auth::User()->slug ])); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('auth.signout')); ?>"><span>Logout</span></a></li>
              <?php endif; ?>
        </ul>
</nav>