<aside class="sidebar">
              <div class="padding-top-2x hidden-lg-up"></div>
              <!-- Widget Categories-->
              <section class="widget widget-categories">
                <?php if($type == 's'): ?>
                  <h3 class="widget-title">Service Categories</h3>
                <?php elseif($type == 'p'): ?>
                  <h3 class="widget-title">Product Categories</h3>
                <?php endif; ?>
                <ul>
                  <?php $__currentLoopData = $cats->where('type', $type); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><a href="#" class="catz" data-id="<?php echo e($cat->id); ?>" data-filter="<?php echo e($cat->slug); ?>"><?php echo e($cat->category); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </ul>
              </section>
             
              <section class="widget subCatWid" style="display:none" >
                <h3 class="widget-title">Filter by Sub Category</h3>
                <span id="subCatz">
                    
                </span>
              </section>
              <!-- Widget Size Filter-->
              
              <!-- Promo Banner-->
              
            </aside>