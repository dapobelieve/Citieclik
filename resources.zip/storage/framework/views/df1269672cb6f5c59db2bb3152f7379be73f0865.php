<div class="shop-sorting">
                  <label for="sorting">Filter by State:</label>
                  <select class="form-control" id="serState">
                    <option value="">All States</option>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option sname="<?php echo e($state->state); ?>" value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select> 
                  <label class="locs" style="display:none" for="sorting">Filter by Location:</label>
                  
                  <select class="form-control locs" style="display:none" id="location">
                  </select>
                  
                </div>