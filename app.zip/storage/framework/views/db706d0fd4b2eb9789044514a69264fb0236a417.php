<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<?php $__env->stopSection(); ?>
<div class="isotope-grid isodata cols-3 mb-2">
    <div class="gutter-sizer"></div>
    <div class="grid-sizer"></div>
    <?php if($listings->count() > 0): ?>
        <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="isoitem grid-item 
                        <?php echo e($data->slugIt($data->catty->slug)); ?> 
                        <?php echo e($data->slugIt($data->loca->lga)); ?> 
                        <?php echo e($data->slugIt($data->state->state)); ?>"
            >
                <div class="recent_ads_item">
                    <div class="item_image">
                        <a class="img_wrapper" href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>">
                            <?php echo $data->getImages(); ?>

                        </a>
                    </div>
                    <div class="item_details ">
                        <div class="ser-title">
                            <a href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>">
                                <?php echo e($data->serviceTitle()); ?>

                            </a>
                        </div>
                        <div style="font-size: 15px" class="location">
                            <?php echo e($data->loca->lga); ?>

                            
                        </div>
                        <div class="item_price">
                            <span style="color: #2bd519" class="ser-price">
                            <?php if(!$data->price == 0): ?>
                            <span> 
                                &#x20A6</span><?php echo e(number_format($data->price)); ?>

                            </span>
                            <?php else: ?> 
                                Negotiable
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No listings yet</p>
    <?php endif; ?>
</div>

        
