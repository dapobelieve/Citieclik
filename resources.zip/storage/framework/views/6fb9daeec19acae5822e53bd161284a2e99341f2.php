<?php $__env->startSection('title'); ?>
    <title>Dashboard :: CitieClik</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-styles'); ?>
<link rel="stylesheet" type="text/css" href="/assets2/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="/assets/css/buttons.dataTables.min.css">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="page-header card">
        <div class="card-block">
            <h5 class="m-b-10">Users</h5>
            <p class="text-muted m-b-10">List of Subscribed users</p>
        </div>
    </div>
    <div class="page-body">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        
                    </div>
                    <div class="card-block">
                        <div class="dt-responsive table-responsive">
                            <table id="simpletable" class="table table-hover table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Firstname</th>
                                        <th>Lastname</th>
                                        <th>Username</th>
                                        <th>Phone No</th>
                                        <th>Email</th>
                                        <th>Date Joined</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->id); ?></td>
                                            <td><?php echo e($user->first_name); ?></td>
                                            <td><?php echo e($user->last_name); ?></td>
                                            <td><?php echo e($user->username); ?></td>
                                            <td><?php echo e($user->phone); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                                
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>







<?php $__env->startSection('admin-scripts'); ?>
<script src="/assets2/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets2/bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="/assets2/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="/assets/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="/assets/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="/assets/js/buttons.print.min.js"></script>


<script type="text/javascript">
    $(document).ready(function (){
        $('#simpletable').DataTable({
            dom: 'lBfrtip',
            "pagingType": "full_numbers",
            buttons: [
                {
                    extend: 'copyHtml5',
                    exportOptions: {
                     columns: ':contains("Office")'
                    }
                },
                {
                    extend: 'pdfHtml5',
                    message: 'PDF created by PDFMake with Buttons for DataTables.'
                },
                'excelHtml5',
                'csvHtml5',
                'pdfHtml5',
                'print'
            ]
        });
    });
</script>
<script src="/assets/js/citi-admin.js"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>