<?php $__env->startSection('title'); ?>
Edit | Profile
<?php $__env->stopSection(); ?>

    <?php $__env->startSection('profileContent'); ?>
        <div class="col-lg-8">
                  <?php if(Session::has('info')): ?>
                  <div class="alert alert-success alert-dismissible fade show text-center margin-bottom-1x">
                    <span class="alert-close" data-dismiss="alert"></span>
                    <i class="icon-help"></i>&nbsp;&nbsp;
                    <strong>Success alert: </strong><?php echo e(Session::get('info')); ?>

                  </div>
                  <?php endif; ?>
            
                    <div class="padding-top-2x mt-2 hidden-lg-up"></div>
                    <form class="row" method="POST" action="<?php echo e(route('profile.edit')); ?>">
                      <div class="col-md-6">
                        <div class="form-group<?php echo e($errors->has('fname') ? ' has-error' : ''); ?>">
                          <label for="account-fn">First Name</label>
                          <input class="form-control" name="fname" value="<?php echo e(Request::old('fname') ?: $user->first_name); ?>" type="text" id="fname" required >
                          <?php if($errors->has('fname')): ?>
                            <span class="help-block formlert">
                              <?php echo e($errors->first('fname')); ?>

                            </span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group<?php echo e($errors->has('lname') ? ' has-error' : ''); ?>">
                          <label for="account-ln">Last Name</label>
                           <input class="form-control" name="lname" value="<?php echo e(Request::old('lname') ?: $user->last_name); ?>" type="text" id="lname" >
                           <?php if($errors->has('lname')): ?>
                              <span class="help-block formlert">
                                <?php echo e($errors->first('lname')); ?>

                              </span>
                            <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                          <label for="account-email">E-mail Address</label>
                          <input class="form-control" name="email" type="email" value="<?php echo e(Request::old('email') ?: $user->email); ?>" id="email" >
                          <?php if($errors->has('email')): ?>
                            <span class="help-block formlert">
                              <?php echo e($errors->first('email')); ?>

                            </span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                          <label for="account-phone">Phone Number</label>
                          <input class="form-control" type="text" name="phone" value="<?php echo e(Request::old('phone') ?: $user->phone); ?>" id="phone" >
                          <?php if($errors->has('phone')): ?>
                            <span class="help-block formlert">
                              <?php echo e($errors->first('phone')); ?>

                            </span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                          <label for="account-pass">Username</label>
                          <input class="form-control" type="text" name="username" value="<?php echo e(Request::old('username') ?: $user->username); ?>" >
                          <?php if($errors->has('username')): ?>
                            <span class="help-block formlert">
                              <?php echo e($errors->first('username')); ?>

                            </span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <?php if(empty($user->password)): ?>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="account-confirm-pass">Please set a Password</label>
                              <input class="form-control" type="password" >
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="account-confirm-pass">Confirm Password</label>
                              <input class="form-control" type="password" id="account-confirm-pass">
                            </div>
                          </div>
                      <?php endif; ?>
                      <div class="col-12">
                        <hr class="mt-2 mb-3">
                        <div class="d-flex flex-wrap justify-content-between align-items-center">
                          
                          <button class="btn btn-primary margin-right-none" type="submit" >Update Profile</button>
                        </div>
                      </div>
                      <?php echo e(csrf_field()); ?>

                    </form>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>