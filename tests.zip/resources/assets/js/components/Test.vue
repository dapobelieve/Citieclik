<template>
    
    <p>This is loaded from vue. BadAss ni mi ooooooooooooooo</p>
</template>

<script>
    export default {
        //
    }
</script>