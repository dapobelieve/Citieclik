<?php $__env->startSection('title'); ?>
Create Account
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-title">
        <div class="container">
          <div class="column">
            <h1>Create Account</h1>
          </div>
          <div class="column">
            <ul class="breadcrumbs">
              <li><a href="index-2.html">Home</a>
              </li>
              <li class="separator">&nbsp;</li>
              <li><a href="#">Register</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!-- Page Content-->
      <div class="container padding-bottom-3x ">
        <div class="row  dparent">
            <div class="col-md-12 pikin">
                <div class="padding-top-3x hidden-md-up"></div>
                <h3 class="margin-bottom-1x">Register</h3>
                <p>It takes few minutes</p>
                <form class="row" method="post" action="<?php echo e(route('agent.pregister')); ?>">
                  <div class="col-sm-6">
                      <div class="form-group<?php echo e($errors->has('fname') ? ' has-error' : ''); ?>">
                          <label for="reg-fn">First Name *</label>
                          <input class="form-control" name="fname" value="<?php echo e(Request::old('fname') ?: ''); ?>" type="text" id="fname" >
                          <?php if($errors->has('fname')): ?>
                            <span class="help-block formlert">
                              <?php echo e($errors->first('fname')); ?>

                            </span>
                          <?php endif; ?>
                      </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group<?php echo e($errors->has('lname') ? ' has-error' : ''); ?>">
                      <label for="reg-ln">Last Name</label>
                      <input class="form-control" name="lname" value="<?php echo e(Request::old('lname') ?: ''); ?>" type="text" id="lname" >
                      <?php if($errors->has('lname')): ?>
                        <span class="help-block formlert">
                          <?php echo e($errors->first('lname')); ?>

                        </span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                      <label for="reg-email">E-mail Address *</label>
                      <input class="form-control" name="email" value="<?php echo e(Request::old('email') ?: ''); ?>" type="email" id="email" >
                      <?php if($errors->has('email')): ?>
                        <span class="help-block formlert">
                          <?php echo e($errors->first('email')); ?>

                        </span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                      <label for="reg-phone">Phone Number *</label>
                      <input class="form-control" type="text"  name="phone" value="<?php echo e(Request::old('phone') ?: ''); ?>" id="phone" >
                      <?php if($errors->has('phone')): ?>
                        <span class="help-block formlert">
                          <?php echo e($errors->first('phone')); ?>

                        </span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                      <label for="reg-pass">Password *</label>
                      <input class="form-control" type="password" name="password" id="password" >
                      <?php if($errors->has('password')): ?>
                        <span class="help-block formlert">
                          <?php echo e($errors->first('password')); ?>

                        </span>
                      <?php endif; ?>
                    </div>
                    <input type="hidden" value="<?php echo e($agentToken->code); ?>" name="token">
                  </div>
                  <div class="col-sm-6<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                    <div class="form-group">
                      <label for="reg-pass-confirm">Confirm Password</label>
                      <input class="form-control" type="password" name="password_confirmation" id="password_confirmation" >
                      <?php if($errors->has('password_confirmation')): ?>
                        <span class="help-block formlert">
                          <?php echo e($errors->first('password_confirmation')); ?>

                        </span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-12 text-center text-sm-right">
                    <button class="btn btn-primary margin-bottom-none" type="submit">Create Account</button>
                  </div>
                  

                </form>
            </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script type="text/javascript">
   <?php if(Session::has('Message')): ?>
    swal({
    title: "oops not allowed",
    text: "<?php echo e(Session::get('Message')); ?>",
    type: 'warning'
  })
  <?php endif; ?>
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>