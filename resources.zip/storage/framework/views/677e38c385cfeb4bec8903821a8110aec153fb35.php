<?php $__env->startSection('title'); ?>
My Requests | Citieclik
<?php $__env->stopSection(); ?>


  <?php $__env->startSection('profileContent'); ?>
      <div class="col-lg-8">
        <div class="padding-top-2x mt-2 hidden-lg-up"></div>
        <div class="table-responsive">
          <table class="table table-hover margin-bottom-none">
            <thead>
              <tr>
                <th>Request Title</th>
                <th>Date Submitted</th>
                
                <th>Priority</th>
                
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $user->getUserReq(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><a class="text-medium navi-link" href="#"><?php echo e($servy->title); ?></a></td>
                  <td><?php echo e($servy->created_at->diffForHumans()); ?></td>
                  
                  <td><span class="text-warning"><?php echo e($servy->priority); ?></span></td>
                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <hr class="mb-4">

        <?php if(Auth::check()): ?>
            <div class="text-right">
              <a href="<?php echo e(route('request.add')); ?>" class="btn btn-primary margin-bottom-none">Submit New Request</a>
            </div>
        <?php endif; ?>
      </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('profile.layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>