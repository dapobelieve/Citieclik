<?php

return [

    'services' => [

        'facebook' => [
                'name' => 'Facebook'
        ],

        'google'  => [
                'name' => 'Gmail'
        ]

    ]
];