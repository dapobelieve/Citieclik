<?php $__env->startSection('title'); ?>
Products | Citieclik
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

 <style>
        *{margin: 0;padding:0px}

      
        .showLeft{
            text-shadow: none !important;
            color:#fff !important;
        }

        .icons li {
            background: none repeat scroll 0 0 #b5a4a4;
            height: 4px;
            width: 4px;
            line-height: 0;
            list-style: none outside none;
            margin-top: 3px;
            vertical-align: top;
            border-radius:50%;
            pointer-events: none;
        }

        .btn-left, .btn-right {
            position: absolute;
        }

        .dropbtn {
            color: white;
            font-size: 16px;
            border: none;*/
            cursor: pointer;
        }
        .show {display:block;}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('profileContent'); ?>
            <div class="col-lg-8">
              <div class="padding-top-2x mt-2 hidden-lg-up"></div>
              <!-- Wishlist Table-->
              <div class="table-responsive wishlist-table  margin-bottom-none">
                  <div class="container service-list">
                    <?php if($user->getUserServices('p')->count()): ?>
                        <?php $__currentLoopData = $user->getUserServices('p'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <div class="row">
                                <div class="col-sm-6 col-md-9">
                                    <div class="product-item"><a class="product-thumb" href="shop-single.html">
                                        <img src=<?php echo e($servy->servieImage()); ?> alt="Service Image"></a>
                                          <div class="product-info">
                                            <h4 class="product-title"><a href="shop-single.html"><?php echo e($servy->title); ?></a></h4>
                                            <div class="text-lg text-medium text-muted">Category: <?php echo e($servy->catty->category); ?></div>
                                            <div>Posted:
                                              <div class="d-inline text-success"><?php echo e($servy->created_at->diffForHumans()); ?></div>
                                            </div>
                                          </div>
                                    </div>
                                </div>
                                <div class="col-sm-3 col-md-3" style="padding-left:100px">
                                     <?php if(Auth::check() && Auth::user()->id == $user->id): ?>
                                        <span class="dropdown">
                                            <!-- three dots -->
                                            <ul style="cursor:pointer" class="dropbtn icons btn-right showLeft" >
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                            </ul>
                                             <div class="dropdown-menu  mybox" style="min-width:0rem; margin-top 12rem"  aria-labelledby="dropdownMenuButton dropdown-menu-left">
                                             <form method="GET" action="<?php echo e(route('service.edit', $servy->id)); ?>">
                                                 <input class="dropdown-item text-primary" style="cursor:pointer" type="submit" value="Edit">
                                                 <?php echo e(csrf_field()); ?>

                                             </form>
                                             <hr>
                                             <form method="POST" class="deletey" action="<?php echo e(route('service.delete', $servy->id)); ?>">
                                                 <input class="dropdown-item text-danger" style="cursor:pointer" type="submit" value="Delete">
                                                 <?php echo e(method_field('DELETE')); ?>

                                                 <?php echo e(csrf_field()); ?>

                                             </form>
                                            </div>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h2>No Products Listed yet </h2>
                    <?php endif; ?>
                  </div>
                
                <br>
                <br>
                <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('addproduct')); ?>">Post new Product</a>
              </div>
             
            </div>      
  <?php $__env->stopSection(); ?>


<?php echo $__env->make('profile.layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>