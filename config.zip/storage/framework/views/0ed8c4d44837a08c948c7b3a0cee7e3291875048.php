<?php $__env->startSection('title'); ?>
    <title>Dashboard :: CitieClik</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-styles'); ?>
<link rel="stylesheet" type="text/css" href="/assets2/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="/assets/css/buttons.dataTables.min.css">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="page-header card">
        <div class="card-block">
            <h5 class="m-b-10">Users</h5>
            <p class="text-muted m-b-10">List of Registered users</p>
        </div>
    </div>
    <div class="page-body">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        
                    </div>
                    <div class="card-block">
                        <div class="dt-responsive table-responsive">
                            <table id="simpletable" class="table table-hover table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Sales Agent?</th>
                                        <th>Joined</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="users">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($user->getFullName()); ?> </td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo e($user->phone); ?></td>
                                            <td style="text-align: center">
                                                <span class="label <?php echo e($user->isAgent() ? 'label-info' : ''); ?>">
                                                <?php echo e($user->isAgent() ? 'agent' : ''); ?>

                                            </span>
                                                
                                            </td>

                                            <td><?php echo e($user->created_at->format('M j, Y')); ?></td>
                                            <td>
                                                <div class="dropdown-primary dropdown open">
                                                    <button class="btn btn-sm btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Options</button>
                                                    <div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                                        <a class="dropdown-item waves-light waves-effect" href="<?php echo e(route('admin.users.details', ['slug' => $user->slug])); ?>">Details</a>
                                                        <a 
                                                            class="dropdown-item add-clicks waves-light md-trigger waves-effect" href="#"
                                                            id="<?php echo e($user->slug); ?>"
                                                            >Add Clicks
                                                        </a>
                                                        
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" tabindex="-1" role="dialog" id="clicks-form">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Add Clicks</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              </div>
              <div class="modal-body">
                <form method="post" action="<?php echo e(route('admin.sub')); ?>">
                    <div class="form-group">
                        <label for="edit-cat">User (username)</label>
                        <input class="form-control" placeholder="Enter amount of clicks" type="text" id="user-slug" readonly name="slug">
                    </div>
                    <div class="form-group">
                        <label for="edit-cat">Select Plan</label>
                        <select class="form-control" name="plan" id="">
                            <option value="basic">Basic</option>
                            <option value="pro">Pro</option>
                            <option value="gold">Gold</option>
                        </select>
                    </div>
                    <?php echo e(csrf_field()); ?>


                    <button class="btn btn-default" >Submit</button>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-scripts'); ?>
<script src="/assets2/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets2/bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="/assets2/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="/assets/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="/assets/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="/assets/js/buttons.print.min.js"></script>

<script src="/assets/js/citi-admin.js"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>