<?php $__env->startSection('title'); ?>
Welcome | Citieclik
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topcat'); ?>

    <section class="homecat">
        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="acat">
                <a  href="<?php echo e(route('category.index', [$data->slug])); ?>"><?php echo e($data->name); ?></a>
                <ul class="top-sub-nav">
                    <?php $__currentLoopData = $data->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('category.index2', [$data->slug, $layer->slug])); ?>">
                            <?php echo e($layer->category); ?>

                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>  
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main Slider-->
    <div class="hero-slider text-center showcase">
      <div class="container padding-top-6x">
        <div id="carouselContent" class="carousel slide bg-chrome item" data-ride="carousel">
          <h1 class="home-text">Connecting the City with a Click</h1>
          <div class="carousel-inner text-white align-items-center" role="listbox">
              <div class="row align-items-center carousel-item align-items-center flex-column p-4 text-center">
                  <form class="form-inline text-center padding-bottom-2x" action="<?php echo e(route('search.results')); ?>">
                    <div class="form-group text-center">
                      
                      <div class="input-group form-group" style="margin-right: 2px !important;">
                        
                        <input type="text" class="form-control" placeholder="looking for?" name="search" id="">
                      </div>
                      <div class="input-group form-group" style="margin-right: 2px !important;">
                        
                        <span id="sList2"></span>
                        
                      </div>
                      <div class="input-group form-group" method="get" style="margin-right: 0px !important;">
                        <select style="color: #bdadb9" class="form-control " id="select-input" name="state">
                          <option  value="">where?</option>
                          <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                      </div>
                          <div class="col-auto">
                            <button type="submit" class="btn btn-primary transparent "><i class="icon-search"></i> Search</button>
                          </div>
                    </div>
                    
                  </form>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Recent Ads Display -->
    <div class="recent_ads">
        <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="recent_ads_item">
                <div class="item_image">
                    <a class="img_wrapper" href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>">
                        <?php echo $data->getImages(); ?>

                    </a>
                </div>
                <div class="item_details ">
                    <div class="ser-title">
                        <a href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>">
                            <?php echo e($data->serviceTitle()); ?>

                        </a>
                    </div>
                    <div style="font-size: 15px" class="location">
                        <?php echo e($data->state->state); ?>, <?php echo e($data->loca->lga); ?>

                    </div>
                    <div class="item_price">
                        <span style="color: #2bd519" class="ser-price">
                        <?php if(!$data->price == 0): ?>
                        <span> 
                            &#x20A6</span><?php echo e(number_format($data->price)); ?>

                        </span>
                        <?php else: ?> 
                            Negotiable
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
    <!--Recent Ads ends here -->

      <section class="padding-bottom-none">
            <div class="fw-section   padding-top-4x padding-bottom-4x" style="background-image: url(/assets/img/banners/home02.jpg);"><span class="overlay rounded" style="opacity: .35;"></span>
              <div class="text-center">
                <h3 class="display-4 text-normal text-white text-shadow mb-1">Become a </h3>
                <h2 class="display-2 text-bold text-white text-shadow">SALES AGENT</h2>
                <h4 class="d-inline-block h2 text-normal text-white text-shadow border-default border-left-0 border-right-0 mb-4">Earn on CitieClik</h4><br>
                <a class="btn btn-primary btn-lg" style="background-color: #03A9F4" href="<?php echo e(route('salesagent.register')); ?>"><i class="icon-signal"></i>&nbsp;Get Started</a>
              </div>
            </div>
      </section>
        
      <section class="padding-bottom-none">
          
          <div id="particles-js" class="container-fluid row col-md-12 padding-bottom-2x mybg" style="color: #fff !important; margin-left: 0px !important;">
                <div class="col-md-12 text-center padding-top-2x" style="color: #ffffff !important;">
                  <h1 class="text-center margin-bottom-2x" style="color: #fff;">How it works at Citieclik</h1>
                </div>
              <div class="col-md-4 col-sm-6 text-center mb-30"><img class="d-block mx-auto mb-4" src="assets/img/icons/step1.png" alt="Register">
                <h3 style="color: #00aeef;">Step 1</h3>
                <h4 style="color: #fff !important; ">Register an Account</h4>
                <p class="text-muted margin-bottom-none" style="color: #fff !important;">Create your free account to get started</p>
              </div>
              <div class="col-md-4 col-sm-6 text-center mb-30"><img class="d-block mx-auto mb-4" src="assets/img/icons/step2.png" alt="Verify">
                <h3 style="color: #00aeef;">Step 2</h3>
                <h4 style="color: #fff !important; ">Verify Your Account</h4>
                <p class="text-muted margin-bottom-none" style="color: #fff !important;">Verify your account for full access to the main features</p>
              </div>
              <div class="col-md-4 col-sm-6 text-center mb-30"><img class="d-block mx-auto mb-4" src="assets/img/icons/step3.png" alt="Add / Request">
                <h3 style="color: #00aeef;">Step 3</h3>
                <h4 style="color: #fff !important; ">Add Services & Request</h4>
                <p class="text-muted margin-bottom-none" style="color: #fff !important;">Add your own services or make requests</p>
              </div>
          </div>       
        
      </section>
      <!-- Featured Products Carousel-->
      <section class="padding-top-none padding-bottom-none margin-bottom-none">
        <div class="container-fluid row padding-left-none padding-right-none">
          <div class="col-md-5 margin-left-none padding-left-none">
            <img src="/assets/img/banners/jobsearch.jpg">
          </div>
          <div class="col-md-7 text-center padding-top-2x padding-right-none margin-left-none" style="background-color: #e7e7e7;">
            <h3 class="h2 text-normal mb-1">Coming soon!!!</h3>
            <h2 class="display-2 text-bold mb-2">Job Search</h2>
            <h4 class="h3 text-normal mb-4">...on citieclik platform</h4>
          </div>
        </div>
      </section>      
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="/assets/js/home.js"></script>
<script type="text/javascript">
 <?php if(Session::has('authMsg')): ?>
  swal({
  title: "Alert",
  text: "<?php echo e(Session::get('authMsg')); ?>",
  type: 'warning'
})
<?php elseif(Session::has('success')): ?>
  swal({
	title: "<?php echo e(Session::get('title')); ?>",
	text:  "<?php echo e(Session::get('success')); ?>",
	type: 'info'
  })
<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>