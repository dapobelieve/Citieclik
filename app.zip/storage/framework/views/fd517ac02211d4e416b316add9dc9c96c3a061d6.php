<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<?php $__env->stopSection(); ?>
<div class="isotope-grid isodata cols-3 mb-2">
	<div class="gutter-sizer"></div>
	<div class="grid-sizer"></div>

	<?php $__currentLoopData = $sdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="isoitem grid-item 
            		<?php echo e($data->slugIt($data->catty->slug)); ?> 
            		<?php echo e($data->slugIt($data->subCat->sub_category)); ?> 
            		<?php echo e($data->slugIt($data->loca->lga)); ?> 
            		<?php echo e($data->slugIt($data->loca->state->state)); ?>"
        >
    		<div class="product-card mybox">
    			<a class="product-thumb" 
    				href=" <?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>">
                        <?php echo $data->getImages(); ?>

                        
    			</a>
    			<h4 class="product-title" style="margin-bottom: 0px !important">
                    <a href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>">
                    </a>
                </h4>
                <div>
                    <h5 class="ser-title">
                    <?php echo e(str_limit(title_case($data->serviceTitle()), 33)); ?>

                    </h5>
                    <span style="color: green" class="price">
                        <?php if(!$data->price == 0): ?>
                        <span>Price: 
                            &#x20A6</span><?php echo e(number_format($data->price)); ?>

                        </span>
                        <?php endif; ?>
                </div>
    			
    			<div class="product-buttons">
    			</div>
    		</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

        <?php echo e($sdata->render()); ?>

