<?php $__env->startSection('title'); ?>
    <title>Dashboard :: CitieClik</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
	<div class="page-header card">
        <div class="card-block">
            <h5 class="m-b-10">Category</h5>
            <p class="text-muted m-b-10">List of registered categories</p>
        </div>
    </div>
	<div class="page-body">
		<div class="row">
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-12 col-lg-4">
		            <div class="card">
		                <div class="card-block text-center">
		                   	<h4 class="m-t-20"><span class="text-c-blue"><?php echo e($category->category); ?></span></h4>
		                   	<p class="m-b-20">Your have <span class="text-c-blue">5</span> subcategories</p>
		                   	<a href="<?php echo e(route('category.index', ['category' => $category->category])); ?>" class="btn btn-primary btn-sm btn-round">Manage subcategories</a>
		                </div>
		            </div>
		          </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-12 col-lg-4">
		            <div class="card">
		                <div class="card-block text-center">
		                   	<h4 class="m-t-20"><span class="text-c-blue ti-plus"></span></h4>
		                   	<p class="m-b-20">Add new category</p>
		                   	<button class="btn btn-primary btn-sm btn-round">Add new</button>
		                </div>
		            </div>
		          </div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>