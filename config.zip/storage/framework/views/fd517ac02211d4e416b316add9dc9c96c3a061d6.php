<div class="isotope-grid isodata cols-3 mb-2">
	<div class="gutter-sizer"></div>
	<div class="grid-sizer"></div>
	<!-- Product-->
    
	<?php $__currentLoopData = $sdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="isoitem grid-item 
		<?php echo e($data->slugIt($data->catty->slug)); ?> 
		<?php echo e($data->slugIt($data->subCat->sub_category)); ?> 
		<?php echo e($data->slugIt($data->loca->lga)); ?> 
		<?php echo e($data->slugIt($data->loca->state->state)); ?>">
					<div class="product-card mybox">
						<div class="product-badge text-primary text-bold"></div><br>
						<div class="text-right"><small class=" text-black"></small></div>
						<a 
							class="product-thumb" 
							href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>">
							<img src="<?php echo e($data->getImages()); ?>" alt="<?php echo e($data->serviceTitle()); ?>" style="width: max; height: 200px !important;">
						</a>
						<h3 class="product-title"><a href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>"><?php echo e($data->serviceTitle()); ?></a></h3>
						
						<div class="product-buttons">
							
							
						</div>
					</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>