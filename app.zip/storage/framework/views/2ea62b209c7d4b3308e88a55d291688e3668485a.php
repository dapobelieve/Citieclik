<?php $__env->startSection('title'); ?>
Create Account
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-title">
        <div class="container">
          <div class="column">
            <h1>Create Account</h1>
          </div>
          <div class="column">
            <ul class="breadcrumbs">
              <li><a href="<?php echo e(route('home')); ?>">Home</a>
              </li>
              <li class="separator">&nbsp;</li>
              </li>
              <li>Login / Register</li>
            </ul>
          </div>
        </div>
      </div>
      <!-- Page Content-->
      <div class="container">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger alert-dismissible fade show margin-bottom-1x">
                <span class="alert-close" data-dismiss="alert"></span><i class="icon-ban"></i>&nbsp;&nbsp;
                <strong>Error alert:</strong>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            </div>
        <?php endif; ?>
            <form class="form-horizontal" method="post" action="<?php echo e(route('populate')); ?>">
                <div class="form-group">
                    <label class="col-md-3 control-label" for="name">Name or Username</label>
                    <div class="col-md-6">
                        <input required type="text" placeholder="Name or Username" name="name" id="name" class="form-control">
                        <?php if($errors->has('name')): ?>
                        <span class="help-block formlert">
                            <?php echo e($errors->first('name')); ?>

                         </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 control-label" for="phone">Phone Number</label>
                    <div class="col-md-6">
                        <input required type="text" name="phone" placeholder="Phone Number" id="phone" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 control-label" for="pass">Password</label>
                    <div class="col-md-6">
                        <input required type="password" name="password" placeholder="Password" id="pass" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary margin-bottom-none" type="submit">Submit</button>
                </div>
            </form>
        
      </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script type="text/javascript">
   <?php if(Session::has('authMsg')): ?>
    swal({
    title: "",
    text: "<?php echo e(Session::get('authMsg')); ?>",
    type: 'info'
  })
  <?php endif; ?>
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>