<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



  <!-- Body-->
  <body>
    <?php echo $__env->yieldContent('request-modal'); ?>
    
    <!-- Off-Canvas Mobile Menu-->
    <div class="offcanvas-container" id="mobile-menu">
      <?php if(Auth::check()): ?>
      <a class="account-link" href="<?php echo e(route('profile.index', ['slug' =>Auth::User()->slug ])); ?>">
        <i class="icon-head"></i>
        <span>Hello</span>, <?php echo e(Auth::User()->first_name); ?> 
      </a>
      <?php endif; ?>
      <?php echo $__env->make('layout.nav2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- Topbar-->
    
    <!-- Navbar-->
    <!-- Remove ".navbar-sticky" class to make navigation bar scrollable with the page.-->
    <header class="navbar navbar-sticky">
      <!-- Search-->
      <form class="site-search" action="<?php echo e(route('quick-search')); ?>" method="get">
        <input type="text" required name="query" placeholder="Quick Search">
        <div class="search-tools"><span class="clear-search">Clear</span><span class="close-search"><i class="icon-cross"></i></span></div>
      </form>
      <div class="site-branding">
        <div class="inner">
          
          <!-- Off-Canvas Toggle (#mobile-menu)--><a class="offcanvas-toggle menu-toggle" href="#mobile-menu" data-toggle="offcanvas"></a>
          <!-- Site Logo--><a class="site-logo" href="/"><img src="/assets/img/logo/logo_bw.png" alt="Citieclik"></a>
        </div>
      </div>
      <!-- Main Navigation-->
      <nav class="site-menu">
        <ul> 
          <li class="<?php echo e(Request::is('/products') ? 'active' : ''); ?>"><a href="<?php echo e(route('product')); ?>"><span>Products</span></a>
          </li>
          <li class="<?php echo e(Request::is('service') ? 'active' : ''); ?>"><a href="<?php echo e(route('service')); ?>"><span>Services</span></a>
          </li>
          
            <ul class="sub-menu">
                <li><a href="<?php echo e(route('signup')); ?>">Login / Register</a></li>
                <li><a href="account-orders.html">Orders List</a></li>
                <li><a href="account-wishlist.html">Wishlist</a></li>
                <li><a href="account-profile.html">Profile Page</a></li>
                <li><a href="account-address.html">Contact / Shipping Address</a></li>
                <li><a href="account-tickets.html">My Tickets</a></li>
            </ul>
          </li>
          
        </ul>
      </nav>
      <!-- Toolbar-->
     <?php echo $__env->make('layout.toolbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>
    <!-- Off-Canvas Wrapper-->
    <div id="app" class="offcanvas-wrapper">
      <!-- Page Content-->
      <?php echo $__env->yieldContent('content'); ?>
      <!-- Site Footer-->
      <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <a class="scroll-to-top-btn" href="#"><i class="icon-arrow-up"></i></a>
    <!-- Backdrop-->
    <div class="site-backdrop"></div>
    <!-- JavaScript (jQuery) libraries, plugins and custom scripts-->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="/assets/js/vendor.min.js"></script>
    <script src="/assets/js/scripts.min.js"></script>
    <script src="/assets/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="/js/jquery.min.js"></script>
    <!-- Customizer scripts-->
    <script src="/assets/customizer/customizer.min.js"></script>  
    <?php echo $__env->yieldContent('script'); ?>    
  </body>

</html>