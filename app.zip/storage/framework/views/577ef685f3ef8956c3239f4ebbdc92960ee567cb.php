    <?php $__env->startSection('title'); ?>
        <title>Dashboard :: CitieClik</title>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('admin-content'); ?>
    <div class="page-body">
       <div class="row">
          <div class="col-md-6 col-xl-3">
             <div class="card bg-c-blue order-card">
                <div class="card-block">
                   <h6 class="m-b-20">Registered Users</h6>
                   <h2 class="text-right"><i class="ti-user f-left"></i><span><?php echo e($users->count()); ?></span></h2>
                </div>
             </div>
          </div>
          <div class="col-md-6 col-xl-3">
             <div class="card bg-c-green order-card">
                <div class="card-block">
                   <h6 class="m-b-20">Services Posted</h6>
                   <h2 class="text-right"><i class=" ti-clipboard f-left"></i><span><?php echo e($services->where('type', 's')->count()); ?></span></h2>
                   
                </div>
             </div>
          </div>
          <div class="col-md-6 col-xl-3">
             <div class="card bg-c-green order-card">
                <div class="card-block">
                   <h6 class="m-b-20">Products Posted</h6>
                   <h2 class="text-right"><i class=" ti-clipboard f-left"></i><span><?php echo e($services->where('type', 'p')->count()); ?></span></h2>
                   
                </div>
             </div>
          </div>
          <div class="col-md-6 col-xl-3">
             <div class="card bg-c-yellow order-card">
                <div class="card-block">
                   <h6 class="m-b-20">Active Subscribers</h6>
                   <h2 class="text-right"><i class="ti-credit-card f-left"></i><span><?php echo e($subcribers->where('status', 1)->count()); ?></span></h2>
                   
                </div>
             </div>
          </div>
          <div class="col-md-6 col-xl-3">
             <div class="card bg-c-pink order-card">
                <div class="card-block">
                   <h6 class="m-b-20">Requests Made</h6>
                   <h2 class="text-right"><i class="ti-wallet f-left"></i><span><?php echo e($requests->count()); ?></span></h2>
                   
                </div>
             </div>
          </div>
            <div class="col-sm-12">
                <div class="card card-block">
                    
                    <user-chart model="users" color="#88d427cc"></user-chart>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card card-block">
                    
                    <count-chart model="clicks" color="#39c586d4"></count-chart>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card card-block">
                    
                    <service-chart model="services" color="#d8c640f0"></service-chart>
                </div>
            </div>
          
      </div> 
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>