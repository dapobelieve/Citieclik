<?php $__env->startSection('title'); ?>
Subscription | CitieClik
<?php $__env->stopSection(); ?>

<?php $__env->startSection('profileContent'); ?>
    <div class="col-lg-8">
        <?php if(Session('pay-message')): ?>
            <div class="alert alert-info alert-dismissible fade show text-center margin-bottom-1x">
              <span class="alert-close" data-dismiss="alert"></span>
              <i class="icon-help"></i>&nbsp;&nbsp;
              <strong>Info: </strong><?php echo e(Session('pay-message')); ?>

            </div>
        <?php endif; ?>
        
        <div class="card card-inverse card-<?php echo e($user->isSubscribed() ? 'success' : 'danger'); ?> text-center mb-2">
              <div class="card-block">
                 <?php if($user->isSubscribed()): ?>
                    <h6 class="card-title">You are currently subscribed to the "<strong><?php echo e($user->getPlan()->plan); ?></strong>" plan.</h6>
                    
                    <?php else: ?>
                         <h6 class="card-title"> <strong>Info:</strong> You are currently not subscribed to any plan</h6>
                    
                    <?php endif; ?>
              </div>
        </div>
        <h6 class="text-muted text-normal text-uppercase padding-top-2x mt-2">Subscriptions</h6>
            <hr class="margin-bottom-1x">
            <ul class="nav nav-tabs" role="tablist">
            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e($plan->id == 1 ? ' active' : ''); ?>" href="#<?php echo e($plan->slug); ?>" data-toggle="tab" role="tab"><?php echo e($plan->plan); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="tab-pane transition fade<?php echo e($plan->id == 1 ? " show active" : ""); ?> " id="<?php echo e($plan->slug); ?>" role="tabpanel">
                    <p><?php echo e($plan->desc); ?></p>
                    <p>Cost: &#8358;<?php echo e(number_format($plan->price)); ?></p>
                    <hr class="margin-bottom-1x">
                    <?php if( !Auth::user()->subscribedToPlan($plan->id) ): ?>
                        <form method="post" action="<?php echo e(route('pay')); ?>">

                            <input type="hidden" name="email" value="<?php echo e(Auth::user()->email); ?>">
                            <input type="hidden" name="amount" value=" 
                            
                                <?php if( Auth::user()->isSubscribed() ): ?>
                                    <?php echo e(( $plan->getPrice() - Auth::user()->getActiveSubFromPlan() )); ?>

                                <?php else: ?>
                                    <?php echo e($plan->getPrice()); ?>

                                <?php endif; ?>
                                 ">
                            <input type="hidden" name="dplan" value="<?php echo e($plan->id); ?>">
                            <input type="hidden" name="dclicks" value="<?php echo e($plan->clicks); ?>">

                            <input 
                                type="hidden" 
                                name="metadata" 
                                value="<?php echo e(json_encode($array = ['plan_id' => $plan->id ,
                                                                'plan_clicks' => $plan->clicks
                                                                ])); ?>" >

                            <input type="hidden" name="key" value="<?php echo e(config('paystack.secretKey')); ?>">

                            <input type="hidden" name="reference" value="<?php echo e(Paystack::genTranxRef()); ?>">
                            
                            <button class="btn btn-primary" type="submit">Subscribe</button>
                            <?php echo e(csrf_field()); ?>


                        </form>
                    <?php endif; ?>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>