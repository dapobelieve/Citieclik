<?php $__env->startSection('style'); ?>
  <link href="/dist/ui/trumbowyg.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Post Ad | Citieclik
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-title">
        <div class="container">
          <div class="column">
          	<?php if($tdata == 'p'): ?>
          		<h1>Post Product Details</h1>
          	<?php elseif($tdata == 's'): ?>
            	<h1>Add New Service </h1>
            <?php endif; ?>
          </div>
          <div class="column">
            <ul class="breadcrumbs">
              <li><a href="<?php echo e(route('home')); ?>">Home</a>
              </li>
              <li class="separator">&nbsp;</li>
              <li>Post a New Ad</li>
            </ul>
          </div>
        </div>
      </div>
		<!-- Page Content-->
      	<div class="container padding-bottom-3x mb-2">
	        <div class="row">
	          <!-- Checkout Adress-->
	          	<div class="col-xl-9 col-lg-8">
		          <?php if(count($errors) > 0): ?>
		            <div class="alert alert-danger alert-dismissible fade show margin-bottom-1x">
			            <span class="alert-close" data-dismiss="alert"></span><i class="icon-ban"></i>&nbsp;
			            <strong>Error alert:</strong>
				            <ul>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li> <?php echo e($error); ?> </li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
		            </div>
		          <?php endif; ?>
		            <h4>Post a New Ad</h4>
		            <hr>
		            <hr class="padding-bottom-1x">
		            <form class="" role="form" method="POST" enctype="multipart/form-data" action="<?php echo e(route('addservice')); ?>">
			            <div class="row" style="margin-top: 20px;">
			              	<div class="col-sm-12">
				                <div class="form-group <?php echo e($errors->has('serTitle') ? ' has-error' : ''); ?>">
				                  	<label for="serTitle">
				                  		<?php if($tdata == 'p'): ?>
				                  			Product Name
				                  		<?php else: ?>
				                  			Service Title
				                  		<?php endif; ?>
				                  	</label>
				                  	<input class="form-control" id="serTitle" name="serTitle"  type="text" placeholder="" value="<?php echo e(Request::old('serTitle') ?: ''); ?>" >
				                  	<?php if($errors->has('serTitle')): ?>
										<p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('serTitle')); ?></p>
					                	
				                	<?php endif; ?>
				                </div>
			              	</div>
			            </div>
			            <div class="row">
			              	<div class="col-sm-6">
				                <div class="form-group <?php echo e($errors->has('serCat') ? ' has-error' : ''); ?>">
				                  	<label for="serCat">Section</label>
				                  	<select class="form-control" onchange="getCat2(this.value)" name="serSec" id="" value="<?php echo e(Request::old('serCat') ?: ''); ?>">
					                    <option>Section</option>
					                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    
				                  	</select>
		  		                  	
				                </div>
			              	</div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <span id="cat2"></span>
                                </div>
                            </div>
	              			<div class="col-sm-6">
				                <div class="form-group">
				                  	<span id="subcat"></span>
				                </div>
			              	</div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <span id="subcat2"></span>
                                </div>
                            </div>

		            	</div>
			            <div class="row">
			              	<div class="col-sm-6">
				                <div class="form-group <?php echo e($errors->has('serState') ? ' has-error' : ''); ?>">
				                  	<label for="serState">State</label>
				                  	<select class="form-control" onchange="getLoco(this.value)" name="serState" id="serState" value="<?php echo e(Request::old('serState') ?: ''); ?>">
				                    	<option>Choose a State</option>
					                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
					                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                  	</select>
				                  	<?php if($errors->has('serState')): ?>
										<p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('serState')); ?></p>
				                	<?php endif; ?>
				                </div>
			              	</div>
			              	<div class="col-sm-6">
				                <div class="form-group <?php echo e($errors->has('location') ? ' has-error' : ''); ?>">

					                <span id="locations"></span>
			                  		<?php if($errors->has('location')): ?>
										<p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('location')); ?></p>
				                	<?php endif; ?>
				                </div>
			              	</div>
			            </div>
			            <div class="row">
			            	<div class="col-md-12">
				            	<div class="form-group">
					              	<label class="col-form-label">Select Image(s) *only jpg, jpeg & png formats allowed. Max size allowed is 2mb.</label>
					              	<div class="">
						                <div class="custom-file">
						                  	<input type="file" name="image[]" multiple>
						                </div>
						            </div>
					            </div>
				            </div>
			            </div>
			            
			            <div class="col-sm-12">
			                <div class="form-group <?php echo e($errors->has('serTitle') ? ' has-error' : ''); ?>">
			                  	<label for="checkout-fn">
			                  			Price
			                  	</label>
			                  	<input class="form-control" name="serPrice" type="number" placeholder="Price " value="<?php echo e(Request::old('serPrice') ?: ''); ?>" >
			                  	<?php if($errors->has('serPrice')): ?>
									<p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('serPrice')); ?></p>
			                	<?php endif; ?>
			                </div>
		              	</div>
		              	
			            <div class="row padding-bottom-1x">
			            	<div class="col-sm-12">
			            		<div class="form-group <?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
				            		<label for="checkout-description">Description</label>
				            		<textarea class="my-editor" name="description" value="<?php echo e(Request::old('description') ?: ''); ?>" placeholder="detailed description goes here..."></textarea>
			                  		<?php if($errors->has('description')): ?>
										<p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('description')); ?></p>
				                	<?php endif; ?>
			            		</div>
			            	</div>
			            </div>
			            <?php if($tdata == 'p'): ?>
			            	<input type="hidden" name="typo" value="p">
			            <?php elseif($tdata == 's'): ?>
			            	<input type="hidden" name="typo" value="s">
			            <?php endif; ?>
			            <div class="form-group">
			            	<button type="submit" class="btn btn-outline-primary btn-block">Submit</button>
			            </div>
			            <?php echo e(csrf_field()); ?>

			        </form>
	          	</div>
	          	<!-- Sidebar          -->
	          	<div class="col-xl-3 col-lg-4">
		            <aside class="sidebar">
		            </aside>
	          	</div>
	        </div>
      	</div>
  	<!--Page Content-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<script src="/dist/trumbowyg.min.js"></script>
<script src="/assets/js/addservice.js"></script>


<script type="text/javascript">
	$('.my-editor').trumbowyg({
		// prefix: 'modern-ui',
		imageWidthModalEdit: true,
		autogrow: true,
	 	btns: [
	        // ['viewHTML'],
	        ['formatting'],
            'btnGrp-semantic',
            ['superscript', 'subscript'],
            // ['link'],
            'btnGrp-justify',
            'btnGrp-lists',
            ['horizontalRule'],
            // ['removeformat'],
            ['backColor'],
	    ]
	});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>