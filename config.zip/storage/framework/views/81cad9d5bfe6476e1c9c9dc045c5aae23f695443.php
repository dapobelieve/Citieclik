

<div class="col-lg-4">
  <aside class="user-info-wrapper">
    <div class="user-cover" style="background-image: url(/assets/img/account/user-cover-img.jpg);">
        <?php if($user->isSubscribed()): ?>
            <div class="info-label subscribed" data-toggle="tooltip" title=""><i class="icon-medal"></i> Subscribed</div>
        <?php else: ?>
            <div class="info-label" data-toggle="tooltip" title="User would not see your contact info">Not Subscribed</div>
        <?php endif; ?>
    </div>
    <div class="user-info">
      <div class="user-avatar">
        <?php if(Auth::check() && Auth::user()->id == $user->id && Request::is('profile/edit')): ?>
        <a class="edit-avatar" data-toggle="modal" data-target="#modalDefault"></a>
        <?php endif; ?>
        <img id="userMainAvatar" src="<?php echo e($user->getUserImg()); ?>" alt="User">
        
      </div>
      <div class="user-data">
        <h4><?php echo e($user->getFullName()); ?></h4>
        <span>
            <small>Joined <?php echo e($user->created_at->formatLocalized('%B %Y')); ?></small>
        </span>
        <?php if($user->isSubscribed()): ?>
            <counter :click="<?php echo e($user->getActiveSubscription()->click); ?>"></counter>
        <?php else: ?>
            <small style="color: #ec2121;">You are not subscribed.</small>
        <?php endif; ?>
      </div>
    </div>
  </aside>
  <nav class="list-group">
    <?php if(Auth::check() && Auth::user()->id == $user->id): ?>
    <a class="list-group-item <?php echo e(Request::is('profile/edit') ? ' active' : ''); ?>" href="<?php echo e(route('profile.edit')); ?>">
      <i class="icon-head"></i>Edit Profile
    </a>
    <?php endif; ?>
    <a class="list-group-item <?php echo e(Request::is( 'subscription') ? ' active' : ''); ?>" href="<?php echo e(route('getSubs')); ?>">
      <i class="icon-map"></i>Manage Subscriptions
    </a>
    <a class="list-group-item justify-content-between 
      <?php echo e(Request::is( 'profile/'.$user->slug.'/services') ? ' active' : ''); ?>" 
      href="<?php echo e(route('profile.service', ['slug' => $user->slug ])); ?>">
      <span><i class="icon-bag"></i>Services</span><span class="badge badge-primary badge-pill"><?php echo e($user->getUserServices('s')->count()); ?></span>
    </a>
    <a class="list-group-item justify-content-between <?php echo e(Request::is( 'profile/'.$user->slug.'/products') ? ' active' : ''); ?>" href="<?php echo e(route('profile.products', ['slug' => $user->slug ])); ?>">
      <span><i class="icon-bag"></i>Products</span><span class="badge badge-primary badge-pill"><?php echo e($user->getUserServices('p')->where('type', 'p')->count()); ?></span>
    </a>
    <a class="list-group-item justify-content-between<?php echo e(Request::is( 'profile/'.$user->slug.'/requests') ? ' active' : ''); ?>" href="<?php echo e(route('profile.request', ['slug' =>$user->slug ])); ?>">
      <span><i class="icon-tag"></i>My Requests</span>
      <span class="badge badge-primary badge-pill"><?php echo e($user->getUserRequests()->count()); ?></span>
    </a>
    <?php if(Auth::user()->isAgent()): ?>
        <a class="list-group-item <?php echo e(Request::is( 'agent/'.Auth::user()->slug) ? ' active' : ''); ?>" href="<?php echo e(route('agent.profile', ['slug' => Auth::user()->slug ])); ?>">
          <i class="icon-check text-success"></i>Agent Dashboard
        </a>
    <?php endif; ?>
  </nav>
</div>

