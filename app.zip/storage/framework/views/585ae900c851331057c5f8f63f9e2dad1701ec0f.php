<?php $__env->startSection('style'); ?>
	 
  
   <link href="/dist/ui/trumbowyg.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="/dist/plugins/colors/ui/trumbowyg.colors.css"">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Request Details | Citieclik
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-title">
		<div class="container">
		<div class="column">
		<h1><?php echo e($requestData->serviceTitle()); ?></h1>
		</div>
		<div class="column">
		<ul class="breadcrumbs">
		<li><a href="index-2.html">Home</a>
		</li>
		<li class="separator">&nbsp;</li>
		<li>Request</li>
		</ul>
		</div>
		</div>
	</div>
	<!-- Page Content-->
	<div class="container padding-bottom-3x mb-2">
		<div class="row"> 
		  <!-- Content-->
		  <div class="col-lg-10 offset-lg-1">
		    <!-- Post-->
		    <div class="single-post-meta">
		      <div class="column">
		        <div class="meta-link"><span>by</span><?php echo e($requestData->userz->getFullName()); ?></div>
		        
		      </div>
		      
		    </div>
		    <h2 class="padding-top-2x"><?php echo e($requestData->serviceTitle()); ?></h2>
		    
		    <textarea class="my-editor" name="description" value="<?php echo e(old('description') ?: ''); ?>" placeholder="Your description goes here..."><?php echo e($requestData->serviceDesc()); ?></textarea>
 	
		    	

		    <div class="single-post-footer">
		      
		    </div>
		  </div>
		</div>
	</div>

  	<!--Page Content-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="/dist/trumbowyg.min.js"></script>
<script type="text/javascript">
//script to auto change states and its lgas
	$('#serState').change(function(){
		$.ajax({
			url: "state/location/"+$(this).val(),
			method: 'GET',
		})
		.done(function(data) {
			$location = $('#location');
			$location.removeAttr('disabled');//enable
			$location.children().remove();//clear the select tag first
			var dee = JSON.parse(data); //convert the json data to array here
			$.each(dee,function(index, value){
				$location.append("<option value='"+value.id+"' >"+ value.lga +"</option>");
			})
		});
	})

	//same logic as above but for
	$('#serCat').change(function(){
		$.ajax({
			url: "category/getscat/"+$(this).val(),
			method: 'GET',
		})
		.done(function(data) {
			$location = $('#subCat');
			$location.removeAttr('disabled');//enable
			$location.children().remove();//clear the kids of the select tag first
			var dee = JSON.parse(data); //convert the json data to array here
			$.each(dee,function(index, value){
				$location.append("<option value='"+value.id+"' >"+ value.sub_category +"</option>");
			})
		});
	})
</script>
<script>
	$('.my-editor').trumbowyg({
		// prefix: 'modern-ui',
		autogrow: true,
		btns: [],
		imageWidthModalEdit: true,
		disabled: true,
		hideButtonTexts: true
	});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>