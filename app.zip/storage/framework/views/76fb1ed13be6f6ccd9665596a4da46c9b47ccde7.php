<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- Body-->
  <body>
    <?php echo $__env->yieldContent('request-modal'); ?>
    
    <!-- Off-Canvas Mobile Menu-->
    <div class="offcanvas-container" id="mobile-menu">
      <?php if(Auth::check()): ?>
      <a class="account-link" href="<?php echo e(route('profile.index', ['slug' =>Auth::User()->slug ])); ?>">
        <i class="icon-head"></i>
        <span>Hello</span>, <?php echo e(Auth::User()->first_name); ?> 
      </a>
      <?php endif; ?>
      <?php echo $__env->make('layout.nav2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- Topbar-->
    
    <!-- Navbar-->
    <!-- Remove ".navbar-sticky" class to make navigation bar scrollable with the page.-->
    
    <header class="navbar fix-header">
      <!-- Search-->
      <form class="site-search" action="<?php echo e(route('quick-search')); ?>" method="get">
        <input type="text" required name="query" placeholder="Quick Search">
        <div class="search-tools"><span class="clear-search">Clear</span><span class="close-search"><i class="icon-cross"></i></span></div>
      </form>
      <div class="site-branding">
        <div class="inner">
            <a class="offcanvas-toggle menu-toggle" href="#mobile-menu" data-toggle="offcanvas"></a>
        </div>
      </div>
      <!-- Main Navigation-->
      
        
            <div class="top-nav">
                <!-- Site Logo-->
                <div class="top-item item-a">
                    <a class="site-logo" href="/"><img src="/assets/img/logo/citilogo.png" alt="Citieclik"></a>
                </div>
                <div class="top-item item-b">
                    <a href="<?php echo e(route('addproduct')); ?>" class="postBtn top-item-link">
                        Post Ad
                    </a>
                </div>
                <?php if(!Auth::check()): ?>
                    <div class="top-item item-c">
                        <a href="<?php echo e(route('signup')); ?>" class="top-item-link">Login</a>
                    </div>
                <?php endif; ?> 
                <?php if(Auth::check()): ?>
                <div class="top-item">
                    <div class="toolbar">
                        
                        <div class="account"><a href="#"></a><i class="icon-head"></i>
                            <ul class="toolbar-dropdown pull-left">
                                  <li class="sub-menu-title" style="font-size: 12px;"><span>Dear,</span><?php echo e(Auth::User()->first_name); ?></li>
                                    <li><a href="<?php echo e(route('profile.index', ['slug' =>Auth::User()->slug ])); ?>">Dashboard</a></li>
                                    <li><a href="<?php echo e(route('profile.service', ['slug' =>Auth::User()->slug ])); ?>">My Services</a></li>
                                    <li><a href="<?php echo e(route('profile.products', ['slug' =>Auth::User()->slug ])); ?>">My Products</a></li>
                                    <li><a href="<?php echo e(route('profile.request', ['slug' =>Auth::User()->slug ])); ?>">My Requests</a></li>
                                    <?php if(Auth::User()->isAdmin()): ?>
                                        <li><a href="<?php echo e(route('admin.home')); ?>">Admin</a></li>
                                    <?php endif; ?>
                                  <li class="sub-menu-separator"></li>
                                  
                                  <li><a href="<?php echo e(route('auth.signout')); ?>"> <i class="icon-unlock"></i>Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                    
                <?php endif; ?>    
            </div>     
    </header>
    <?php echo $__env->yieldContent('topcat'); ?>
    <!-- Off-Canvas Wrapper-->
    <div id="app" class="offcanvas-wrapper">
      <!-- Page Content-->
      <?php echo $__env->yieldContent('content'); ?>
      <!-- Site Footer-->
      <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <a class="scroll-to-top-btn" href="#"><i class="icon-arrow-up"></i></a>
    <!-- Backdrop-->
    
    <!-- JavaScript (jQuery) libraries, plugins and custom scripts-->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="/assets/js/vendor.min.js"></script>
    <script src="/assets/js/scripts.min.js"></script>
    <script src="/assets/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="/js/jquery.min.js"></script>
    <!-- Customizer scripts-->
    <script src="/assets/customizer/customizer.min.js"></script>  
    <?php echo $__env->yieldContent('script'); ?>    
  </body>

</html>