<?php $__env->startSection('title'); ?>
<?php echo e($catName); ?> Services
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Title-->
      <div class="page-title">
        <div class="container">
          <div class="column">
            <h1>Services | <?php echo e($catName); ?></h1>
          </div>
          <div class="column">
            <ul class="breadcrumbs">
              <li><a href="<?php echo e(route('home')); ?>">Home</a>
              </li>
              <li class="separator">&nbsp;</li>
              <li>Services</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Page Content-->
      <div class="container padding-bottom-3x mb-1">
        <div class="row hereIt">
          <!-- Products-->
          <div class="col-xl-9 col-lg-8 push-xl-3 push-lg-4">
            <!-- Shop Toolbar-->
            <div class="shop-toolbar padding-bottom-1x mb-2">
              <div class="column">
                <?php echo $__env->make('service.layout.state-filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </div>
              <div class="column">
                  
              </div>
            </div>
            <!-- Products Grid-->
            <div class="isotope-grid isodata cols-3 mb-2">
                <div class="gutter-sizer"></div>
                <div class="grid-sizer"></div>

                <?php $__currentLoopData = $sdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="isoitem grid-item 
                                <?php echo e($data->slugIt($data->catty->slug)); ?> 
                                <?php echo e($data->slugIt($data->subCat->sub_category)); ?> 
                                <?php echo e($data->slugIt($data->loca->lga)); ?> 
                                <?php echo e($data->slugIt($data->loca->state->state)); ?>"
                    >
                        <div class="product-card mybox">
                            <div class="product-badge text-primary text-bold"></div><br>
                            <div class="text-right"><small class=" text-black"></small></div>
                            <a 
                                class="product-thumb" 
                                href=" <?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>">
                                <img src="<?php echo e($data->getImages()); ?>" alt="<?php echo e($data->serviceTitle()); ?>" style="width: max; height: 200px !important;">
                            </a>
                            <h4 class="product-title">
                                <a href="<?php echo e(route('service.detail',['username' => $data->userz->username,'slug' => $data->slug])); ?>">
                                    <?php echo e(title_case($data->serviceTitle())); ?>

                                </a>
                            </h4>
                            
                            <div class="product-buttons">
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
          <!-- Sidebar          -->
          <div class="col-xl-3 col-lg-4 pull-xl-9 pull-lg-8">
            <aside class="sidebar">
              <div class="padding-top-2x hidden-lg-up"></div>
              <!-- Widget Categories-->
                           
              <section class="widget subCatWid">
                <h3 class="widget-title">Sub Categories</h3>
                <span id="subCatz">
                <?php $__currentLoopData = $subCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="custom-control custom-checkbox d-block">
                           <input class="custom-control-input" type="checkbox" value=".<?php echo e($subCat->slug); ?>">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo e($subCat->sub_category); ?>&nbsp;
                            
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </span>
              </section>
              <!-- Widget Size Filter-->
              
              <!-- Promo Banner-->
            </aside>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/assets/js/isotope.js"></script>
<script>
  var url1 = "category-h/state/";
</script>
<script src="/assets/js/service.js"></script>
<script type="text/javascript">

function isotopeIts(theValue)
{
  $grid.isotope({ filter: theValue });
}


  var checkboxes = $('#subCatz input');
  checkboxes.change( function() {
  // map input values to an array
  var inclusives = [];
  // inclusive filters from checkboxes
  checkboxes.each( function( i, elem ) {
    // if checkbox, use value if checked
    if ( elem.checked ) {
      inclusives.push( elem.value );
    }
  });
    var filterValue = inclusives.length ? inclusives.join(', ') : '*';
    // console.log(filterValue);
    isotopeIts(filterValue);
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>