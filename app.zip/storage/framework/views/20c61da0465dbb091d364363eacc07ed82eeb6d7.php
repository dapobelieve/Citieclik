<?php $__env->startSection('title'); ?>
Verfication Successful
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

      <div class="container padding-top-3x padding-bottom-3x mb-1"><img class="d-block img-responsive m-auto" src="/assets/img/emailVerify.png" style="width: 20%; height: 20% max-width: 550px;" alt="verified">
        <div class="padding-top-1x mt-2 text-center">
          <h1>Congratulations!!!</h1>
          <p>Your Email has been verified successfully. Continue <a href="<?php echo e(route('home')); ?>">Here</a></p>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>