<?php $__env->startSection('style'); ?>
     
  <link href="/dist/ui/trumbowyg.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="/dist/plugins/colors/ui/trumbowyg.colors.css"">
  <script type="text/javascript">
          // image previewwer
        function preview_image(event) 
        {
         var reader = new FileReader();
         reader.onload = function()
         {
          var output = document.getElementById('output_image');
          output.src = reader.result;
         }
         reader.readAsDataURL(event.target.files[0]);
        };
  </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Request for a Service 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="container">
          <div class="column">
            <h1>Submit New Request</h1>
          </div>
          <div class="column">
            <ul class="breadcrumbs">
              <li><a href="index-2.html">Home</a>
              </li>
              <li class="separator">&nbsp;</li>
              <li>Request Service</li>
            </ul>
          </div>
        </div>
      </div>
        <!-- Page Content-->
        <div class="container padding-bottom-3x mb-2">
            <div class="row">
              <!-- Checkout Adress-->
                <div class="col-xl-9 col-lg-8">
                    <?php if(Session::has('error_message') ): ?>
                        <?php echo e(Session::get('error_message')); ?>

                    <?php endif; ?>
                  <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger alert-dismissible fade show margin-bottom-1x">
                        <span class="alert-close" data-dismiss="alert"></span><i class="icon-ban"></i>&nbsp;&nbsp;
                        <strong>Error alert:</strong>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li> <?php echo e($error); ?> </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                    </div>
                  <?php endif; ?>
                    <h6><em>*Users will get an sms alert of your request within few minutes.*</em></h6><br>
                    <form class="" role="form" method="POST" enctype="multipart/form-data" action="<?php echo e(route('request.add')); ?>">
                        <div class="row" style="margin-top: 20px;">
                            <div class="col-sm-12">
                                <div class="form-group <?php echo e($errors->has('serTitle') ? ' has-error' : ''); ?>">
                                    <label for="checkout-fn">What Do you Want?</label>
                                    <input class="form-control" name="serTitle" type="text" placeholder="What Do you Want?" value="<?php echo e(old('serTitle') ?: ''); ?>" required>
                                    <?php if($errors->has('serTitle')): ?>
                                        <p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('serTitle')); ?></p>
                                        
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                  <label for="ticket-priority">How urgent is your issue? (Priority)</label>
                                  <select name="serPrior" class="form-control" name="priority" id="ticket-priority">
                                    <option value="Urgent">Urgent</option>
                                    <option value="High">High</option>
                                    <option value="Medium">Medium</option>
                                    <option value="Low">Low</option>
                                  </select>
                                </div>
                            </div>
                            <div class="col-sm-6"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group <?php echo e($errors->has('serCat') ? ' has-error' : ''); ?>">
                                    <label for="checkout-country">Category</label>
                                    <select class="form-control" onchange="getSubCat(this.value)" name="serCat" id="serCat" value="<?php echo e(old('serCat') ?: ''); ?>">
                                        <option value="">Choose a Category</option>
                                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('serCat')): ?>
                                        <p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('serCat')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <span id="subcatty"></span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <span id="subcatty2"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group <?php echo e($errors->has('serState') ? ' has-error' : ''); ?>">
                                    <label for="checkout-country">State</label>
                                    <select class="form-control" onchange="getLoco(this.value)" name="serState" id="serState" value="<?php echo e(old('serState') ?: ''); ?>">
                                        <option value="">Choose a State</option>
                                        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('serState')): ?>
                                        <p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('serState')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group <?php echo e($errors->has('location') ? ' has-error' : ''); ?>">

                                    <span id="locations"></span>
                                    <?php if($errors->has('location')): ?>
                                        <p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('location')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>                        
                        <div class="row padding-bottom-1x">
                            <div class="col-sm-12">
                                <div class="form-group <?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                    <label for="checkout-description">Description</label>
                                    <textarea  name="description" placeholder="Your description goes here..." id="my-editor" >
                                        <?php echo e(Request::old('description') ?: ''); ?>

                                    </textarea>
                                    <?php if($errors->has('description')): ?>
                                        <p class="help-block text-danger"><i class="icon-circle-cross"></i>&nbsp;<?php echo e($errors->first('description')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-outline-primary btn-block">Submit</button>
                        </div>
                        
                    </form>
                </div>
                <!-- Sidebar          -->
                <div class="col-xl-3 col-lg-4">
                    
                </div>
            </div>
        </div>
    <!--Page Content-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="/dist/trumbowyg.min.js"></script>
<script src="/dist/plugins/colors/trumbowyg.colors.min.js"></script>
<script src="/assets/js/addservice.js"></script>
<script type="text/javascript">
// text editor
(function() {
    $('#my-editor').trumbowyg({
        autogrow: true,
        btns: [
            // ['viewHTML'],
            ['formatting'],
            'btnGrp-semantic',
            ['superscript', 'subscript'],
            // ['link'],
            'btnGrp-justify',
            'btnGrp-lists',
            ['horizontalRule'],
            // ['removeformat'],
            ['backColor'],
            // ['fullscreen']
        ]
    });
})();
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>